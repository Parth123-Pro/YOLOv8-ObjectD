# Introduction

This project aims to build a personalized object detection system using YOLOv8. The model is trained to recognize specific individuals and display their names when detected by the live camera feed.

Requirements

Python 3.8 or later
Ultralytics YOLO
OpenCV
LabelImg (for dataset annotation)

# Contact

Issues should be raised directly in the repository. For additional questions or comments please email Parth Parmar at pparmar2759@gmail.com.