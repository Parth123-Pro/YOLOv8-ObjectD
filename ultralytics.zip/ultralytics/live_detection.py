import cv2
from ultralytics import YOLO

# Load the trained YOLOv8 model
model = YOLO('runs/detect/train43/weights/best.pt')  # Update the path if necessary

# Initialize the camera
cap = cv2.VideoCapture(0)  # 0 is the default camera

# Check if the camera opened successfully
if not cap.isOpened():
    print("Error: Could not open camera.")
    exit()

# Loop to continuously get frames
while True:
    # Capture frame-by-frame
    ret, frame = cap.read()
    if not ret:
        print("Error: Failed to capture image")
        break

    # Run the YOLOv8 model on the frame
    results = model(frame)

    # Render the results on the frame
    for result in results:
        result_frame = result.plot()

    # Display the 
